public class Book {
    private String ISBN;
    private String title;
    private int PublishingYear;

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPublishingYear() {
        return PublishingYear;
    }

    public void setPublishingYear(int publishingYear) {
        PublishingYear = publishingYear;
    }

    public Book(String ISBN, String title, int PublishingYear) {
        this.ISBN = ISBN;
        this.title = title;
        this.PublishingYear = PublishingYear;
    }

    public boolean ComparingISBN(String ISBN){
        if(this.ISBN.equals(ISBN)){
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Book{" +
                "ISBN='" + ISBN + '\'' +
                ", title='" + title + '\'' +
                ", PublishingYear=" + PublishingYear +
                '}';
    }
}
