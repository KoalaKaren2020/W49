
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<String> StringList = new ArrayList<>();

        System.out.println("String hello");
        System.out.println("String World");
        System.out.println("String Monkey");
        System.out.println("String Tiger");
        System.out.println("String Pie");
        System.out.println("String Bear");
    }




}
